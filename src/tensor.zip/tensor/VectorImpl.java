package tensor;

class VectorImpl {
}
