package tensor;

public class Tensors {
    public static Scalar addScalar(Scalar scalar1, Scalar scalar2) {
        return Scalar.add(scalar1, scalar2);
    }

    public static Scalar multiplyScalar(Scalar scalar1, Scalar scalar2) {
        return Scalar.multiply(scalar1, scalar2);
    }

    public static Vector addVector(Vector vector1, Vector vector2) {
        return Vector.add(vector1, vector2);
    }

    public static Vector multiplyVector(Vector vector, Scalar scalar) {
        return Vector.multiply(vector, scalar);
    }

    public static Matrix addMatrix(Matrix matrix1, Matrix matrix2) {
        return Matrix.add(matrix1, matrix2);
    }

    public static Matrix multiplyMatrix(Matrix matrix1, Matrix matrix2) {
        return Matrix.multiply(matrix1, matrix2);
    }

    public static Matrix concatenateMatrix(Matrix matrix1, Matrix matrix2, int axis) {
        return Matrix.concatenate(matrix1, matrix2, axis);
    }
}
