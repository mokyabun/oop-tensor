package tensor;

class MatrixImpl {
}
