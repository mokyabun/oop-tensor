package tensor;

// TODO: implement interface
class ScalarImpl {
}
